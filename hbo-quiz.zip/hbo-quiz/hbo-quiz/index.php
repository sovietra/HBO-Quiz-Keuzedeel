<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HBO QUIZ</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrapper">
        <div class="container">
            <img src="background.png" class="background">
            <img src="foreground.png" class="foreground">
             <h1>HBO QUIZ</h1>
             <h3>Software Engineering, Security en Cloud Quiz</h3>
        </div>

        <section>
            <h2 class="adven">Sectie 1: Software Engineering</h2>
            <p>Wat is het hoofddoel van de Agile-methodologie in softwareontwikkeling?
                <br>
                <br>
                A: Kosten verlagen
                <br>
                B: Snel en iteratief werkende software leveren
                <br>
                C: De noodzaak van testen elimineren
                <br>
                D: Alleen focussen op documentatie
            </p>
            <div class="bg1">
            </div>
            <h2 class="adven">Sectie 1: Software Engineering</h2>
            <p>Welke van de volgende is GEEN levenscyclusmodel voor softwareontwikkeling?
                <br>
                <br>
                A: Waterval
                <br>
                B: Spiraal
                <br>
                C: Blockchain
                <br>
                D: V-model
            </p>

            <div class="bg2">
            </div>
            <h2 class="adven">Sectie 1: Software Engineering</h2>
            <p>Waar staat SOLID voor in objectgeoriënteerd ontwerp?
                <br>
                <br>
                A:  Eenvoudig, geoptimaliseerd, logisch, onafhankelijk, dynamisch
                <br>
                B: Enkele verantwoordelijkheid, open-gesloten, Liskov-substitutie, interface-segregatie, afhankelijkheidsomkering
                <br>
                C: Systematisch, geordend, gelaagd, geïntegreerd, gedistribueerd
                <br>
            </p>

            <div class="bg3">
            </div>
            <h2 class="adven">Sectie 1: Software Engineering</h2>
            <p>Welk programmeerparadigma wordt het meest geassocieerd met Java en C++?
                <br>
                <br>
                A: Functioneel
                <br>
                B: Objectgeoriënteerd
                <br>
                C: Procedureel
                <br>
                D: Logicagebaseerd
            </p>






        </section>
    </div>
</body>
</html>
</body>
</html>